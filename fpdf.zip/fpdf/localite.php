<?php
require "../session.php";
require "../dbconnexion.php";


$bdd = new PDO('mysql:host=localhost;dbname=minddevel;', 'root', '');
if($_SESSION['user']['role']=="collecteur")
    if($cec = $_SESSION['user']['code']){
        $bdd = new PDO('mysql:host=localhost;dbname=minddevel;', 'root', '');
        $sql = $bdd->query("SELECT FR, datecreation, cec.code, region.code_region, localite, nbrregnais, nbrregmar, nbrregdec, nbrregpara, nbrregclot, nbractmar, nbractnai, nbractdec, fonctionnel, commentaire FROM cec INNER JOIN  region ON cec.code_region=region.code_region INNER join statistique ON statistique.code = cec.code where cec.code='$cec'");
    }
    $stmt = $pdo->query("SELECT DISTINCT localite FROM cec INNER JOIN  region ON cec.code_region=region.code_region INNER join statistique ON statistique.code = cec.code WHERE cec.code ='$cec'"); $zu = $stmt->fetchColumn();
?>



<?php
require('fpdf.php');

$pdf = new FPDF('P', 'mm', 'A3');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Image('../img/cmr.png',140,10,-300);
$pdf->Cell(0,50, "MINISTERE DE LA DECENTRALISATION ET DU DEVELOPPEMENT LOCAL", '', 1, 'C');
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,-28, "HISTORIQUE DES COLLECTES LOCALITE $zu", '', 1, 'C');

$pdf->Cell(0,20,'',0,1);
$pdf->Ln(5);
//is equivalent to:
$pdf->SetFont('Arial','B',8);
$pdf->SetFillColor(180,180,250);
$pdf->SetDrawColor(180,180,255);

$pdf->Cell(20,5,"Date",1,0,'',true);
$pdf->Cell(30,5,"Localite",1,0,'',true);
$pdf->Cell(18,5,"Code",1,0,'',true);
$pdf->Cell(22,5,"Reg.Naissance",1,0,'',true);
$pdf->Cell(22,5,"Reg.Mariage",1,0,'',true);
$pdf->Cell(20,5,"Reg.Deces",1,0,'',true);
$pdf->Cell(22,5,"Reg.Paraphe",1,0,'',true);
$pdf->Cell(25,5,"Reg.Cloture",1,0,'',true);
$pdf->Cell(25,5,"Act.Naissance",1,0,'',true);
$pdf->Cell(25,5,"Act.Mariage",1,0,'',true);
$pdf->Cell(25,5,"Act.Deces",1,0,'',true);
$pdf->Cell(35,5,"Etat",1,0,'',true);

$pdf->AliasNbPages('{pages}');

$pdf->SetAutoPageBreak(true,15);

$pdf->SetFont('Arial','',9);
$pdf->SetDrawColor(180,180,255);
$bdd = new PDO('mysql:host=localhost;dbname=minddevel;', 'root', '');
if($sql->rowCount() > 0){
    while($data = $sql->fetch()){
    $pdf->Cell(20,5,$data['datecreation'],'LR',0);
	$pdf->Cell(30,5,$data['localite'],'LR',0);
    $pdf->Cell(18,5,$data['code'],'LR',0);
	$pdf->Cell(22,5,$data['nbrregnais'],'LR',0);
    $pdf->Cell(22,5,$data['nbrregmar'],'LR',0);
    $pdf->Cell(20,5,$data['nbrregdec'],'LR',0);
    $pdf->Cell(22,5,$data['nbrregpara'],'LR',0);
    $pdf->Cell(25,5,$data['nbrregclot'],'LR',0);
    $pdf->Cell(25,5,$data['nbractnai'],'LR',0);
    $pdf->Cell(25,5,$data['nbractmar'],'LR',0);
    $pdf->Cell(25,5,$data['nbractdec'],'LR',0);
    $pdf->Cell(35,5,$data['fonctionnel'],'LR',0);
    
	
	if($pdf->GetStringWidth($data['FR']) > 65){
	$pdf->SetFont('Arial','',12);
	$pdf->Cell(25,5,$data['FR'],'LR',0);

	}else{
	$pdf->Cell(65,5,$data['FR'],'LR',0);
	}
	$pdf->Cell(80,5,$data['code_region'],'LR',1);
    }
}

$pdf->Output();

?>