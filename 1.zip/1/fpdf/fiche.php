<?php
require '../dbconnexion.php';
require '../session.php';
require('fpdf.php');

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM user where id= '$id'");
$stmt->execute([':id' => $id ]);
$collecte = $stmt->fetchObject();

$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Image('../img/cmr.png',95,10,-300);
$pdf->Cell(0,50, "MINISTERE DE LA DECENTRALISATION ET DU DEVELOPPEMENT LOCAL", '', 1, 'C');
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,-28, "FICHE DE L'UTILISATEUR", '', 1, 'C');
$pdf->SetFont('Arial','B',12);
$pdf->Cell(50,130, "Nom: $collecte->nom", '', 1, 'C');
$pdf->Cell(250,-130, "Prenom: $collecte->prenom  ", '', 1, 'C');
$pdf->Cell(50,170, "Sexe: $collecte->sexe", '', 1, 'C');
$pdf->Cell(250,-170, "Identifiant: $collecte->identifiant", '', 1, 'C');
$pdf->Cell(50,210, "Poste: $collecte->poste", '', 1, 'C');
$pdf->Cell(250,-210, "Role:  $collecte->role", '', 1, 'C');

$pdf->Output();

?>