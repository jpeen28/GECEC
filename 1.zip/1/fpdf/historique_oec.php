<?php 
require "../session.php";
require "../dbconnexion.php";


$bdd = new PDO('mysql:host=localhost;dbname=minddevel;', 'root', '');
$sql = $bdd->query('select *  from nouveauoec');

require('fpdf.php');

$pdf = new FPDF('P', 'mm', 'A3');
$pdf->AddPage();
$pdf->SetFont('Arial','B',20);
$pdf->Image('../img/cmr.png',140,10,-300);
$pdf->Cell(0,50, "MINISTERE DE LA DECENTRALISATION ET DU DEVELOPPEMENT LOCAL", '', 1, 'C');
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,-28, "HISTORIQUE DE NOMINATION DES OFFICIERS ETAT CIVIL ", '', 1, 'C');

$pdf->Cell(0,20,'',0,1);
$pdf->Ln(5);
//is equivalent to:
$pdf->SetFont('Arial','B',12);
$pdf->SetFillColor(180,180,250);
$pdf->SetDrawColor(180,180,255);


$pdf->Cell(50,5,"Nom Officier",1,0,'',true);
$pdf->Cell(30,5,"Reference",1,0,'',true);
$pdf->Cell(35,5,"Date Naissance",1,0,'',true);
$pdf->Cell(50,5,"Lieu Naissance",1,0,'',true);
$pdf->Cell(20,5,"Age",1,0,'',true);
$pdf->Cell(25,5,"Sexe",1,0,'',true);
$pdf->Cell(30,5,"Poste",1,0,'',true);
$pdf->Cell(50,5,"Diplome",1,0,'',true);

$pdf->SetAutoPageBreak(true,15);

$pdf->SetFont('Arial','',12);
$pdf->SetFillColor(180,180,250);
$pdf->SetDrawColor(180,180,255);

if($sql->rowCount() > 0){
	while($data = $sql->fetch()){
	$pdf->Cell(50,5,$data['nomoec'],'LR',0);
    $pdf->Cell(30,5,$data['reference'],'LR',0);
	$pdf->Cell(35,5,$data['datenaissance'],'LR',0);
    $pdf->Cell(50,5,$data['lieunaissance'],'LR',0);
    $pdf->Cell(20,5,$data['age'],'LR',0);
    $pdf->Cell(25,5,$data['sexe'],'LR',0);
    $pdf->Cell(30,5,$data['poste'],'LR',0);
    $pdf->Cell(50,5,$data['diplome'],'LR',0);
	
	
	if($pdf->GetStringWidth($data['sexe']) > 65){
	$pdf->SetFont('Arial','',12);
	$pdf->Cell(25,5,$data['sexe'],'LR',0);

	}else{
	$pdf->Cell(65,5,$data['sexe'],'LR',0);
	}
	$pdf->Cell(80,5,$data['age'],'LR',1);
	}
}
$pdf->SetFillColor(180,180,250);
$pdf->Ln(5);

$pdf->Output();
?>