
<?php
require('fpdf.php');
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'minddevel');


class PDF extends FPDF {
	function Header(){
		$this->SetFont('Arial','B',22);

		$this->Image('../img/cmr.png',130,10,30);
		
		$this->Cell(0,80,'MINISTERE DE LA DECENTRALISATION ET DU DEVELOPPEMENT LOCAL','', 1, 'C');

        $this->SetFont('Arial','B',14);
        $this->Cell(0,0,"HISTORIQUES DE CREATION DES CENTRES D'ETAT CIVIL",'', 1, 'C');
		
		$this->Cell(0,5,'',0,1);
		//is equivalent to:
		$this->Ln(5);
        
		
		$this->SetFont('Arial','B',12);
		
		$this->SetFillColor(180,180,250);
		$this->SetDrawColor(180,180,255);
		$this->Cell(10,5,'#',1,0,'',true);
		$this->Cell(25,5,'Date',1,0,'',true);
		$this->Cell(35,5,'Region',1,0,'',true);
		$this->Cell(45,5,'Departement',1,0,'',true);
        $this->Cell(45,5,'Arrondissement',1,0,'',true);
        $this->Cell(45,5,'Nom du centre',1,0,'',true);
        $this->Cell(45,5,'Centre rattachement',1,0,'',true);
        $this->Cell(55,5,'Etat',1,0,'',true);
 	
	}
	function Footer(){
		//add table's bottom line
		$this->Cell(300,0,'','T',1,'',true);
		
		//Go to 1.5 cm from bottom
		$this->SetY(-15);
				
		$this->SetFont('Arial','',10);
		
		//width = 0 means the cell is extended up to the right margin
		$this->Cell(0,10,'Page '.$this->PageNo()." / {pages}",0,0,'C');
	}
}


$pdf = new PDF('P','mm','A3'); //use new class

//define new alias for total page numbers
$pdf->AliasNbPages('{pages}');

$pdf->SetAutoPageBreak(true,15);
$pdf->AddPage();

$pdf->SetFont('Arial','',10);
$pdf->SetDrawColor(180,180,255);


$query=mysqli_query($con,"SELECT * FROM nouveaucec");
while($data=mysqli_fetch_array($query)){
	$pdf->Cell(10,5,$data['id'],'LR',0);
	$pdf->Cell(25,5,$data['date'],'LR',0);
    $pdf->Cell(35,5,$data['code_region'],'LR',0);
	$pdf->Cell(45,5,$data['departement'],'LR',0);
    $pdf->Cell(45,5,$data['code_cec'],'LR',0);
    $pdf->Cell(45,5,$data['localite'],'LR',0);
    $pdf->Cell(45,5,$data['rattachement'],'LR',0);
    $pdf->Cell(55,5,$data['etat'],'LR',0);
	if($pdf->GetStringWidth($data['id']) > 65){
	$pdf->SetFont('Arial','',12);
	$pdf->Cell(25,5,$data['id'],'LR',0);

	}else{
	$pdf->Cell(65,5,$data['id'],'LR',0);
	}
	$pdf->Cell(80,5,$data['id'],'LR',1);
}




$pdf->Output();
?>