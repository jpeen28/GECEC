
<?php
require('fpdf.php');
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'minddevel');


class PDF extends FPDF {
	function Header(){
		$this->SetFont('Arial','B',20);

		$this->Image('../img/cmr.png',135,10,30);
		
		$this->Cell(0,80,'MINISTERE DE LA DECENTRALISATION ET DU DEVELOPPEMENT LOCAL','', 1, 'C');

        $this->SetFont('Arial','B',15);
        $this->Cell(0,0,'HISTORIQUES DES COLLECTES NATIONALES','', 1, 'C');
		
		$this->Cell(0,5,'',0,1);
		//is equivalent to:
		$this->Ln(5);
		
		$this->SetFont('Arial','B',10);
		
		$this->SetFillColor(180,180,250);
		$this->SetDrawColor(180,180,255);
		$this->Cell(25,5,'Region',1,0,'',true);
		$this->Cell(15,5,'Code',1,0,'',true);
		$this->Cell(30,5,'Reg.Naissance',1,0,'',true);
		$this->Cell(25,5,'Reg.Mariage',1,0,'',true);
        $this->Cell(22,5,'Reg.Deces',1,0,'',true);
        $this->Cell(25,5,'Reg.Paraphe',1,0,'',true);
        $this->Cell(25,5,'Reg.Cloture',1,0,'',true);
        $this->Cell(40,5,'Act.Naissance',1,0,'',true);
        $this->Cell(40,5,'Act.Mariage',1,0,'',true);
        $this->Cell(40,5,'Act.Deces',1,1,'',true);		
	}
	function Footer(){
		//add table's bottom line
		$this->Cell(300,0,'','T',1,'',true);
		
		//Go to 1.5 cm from bottom
		$this->SetY(-15);
				
		$this->SetFont('Arial','',8);
		
		//width = 0 means the cell is extended up to the right margin
		$this->Cell(0,10,'Page '.$this->PageNo()." / {pages}",0,0,'C');
	}
}


//A4 width : 219mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm

$pdf = new PDF('P','mm','A3'); //use new class

//define new alias for total page numbers
$pdf->AliasNbPages('{pages}');

$pdf->SetAutoPageBreak(true,15);
$pdf->AddPage();

$pdf->SetFont('Arial','',9);
$pdf->SetDrawColor(180,180,255);

$query=mysqli_query($con,"SELECT FR, region.code_region, (SUM(nbrregnais)),(SUM(nbrregmar)),(SUM(nbrregdec)), (SUM(nbrregpara)), (SUM(nbrregclot)),(SUM(nbractmar)),(SUM(nbractnai)),(SUM(nbractdec)) FROM cec INNER JOIN region ON cec.code_region=region.code_region INNER join statistique ON statistique.code = cec.code GROUP BY FR");
while($data=mysqli_fetch_array($query)){
	$pdf->Cell(25,5,$data['FR'],'LR',0);
	$pdf->Cell(15,5,$data['code_region'],'LR',0);
    $pdf->Cell(30,5,$data['(SUM(nbrregnais))'],'LR',0);
	$pdf->Cell(25,5,$data['(SUM(nbrregmar))'],'LR',0);
    $pdf->Cell(22,5,$data['(SUM(nbrregdec))'],'LR',0);
    $pdf->Cell(25,5,$data['(SUM(nbrregpara))'],'LR',0);
    $pdf->Cell(25,5,$data['(SUM(nbrregclot))'],'LR',0);
    $pdf->Cell(40,5,$data['(SUM(nbractmar))'],'LR',0);
    $pdf->Cell(40,5,$data['(SUM(nbractnai))'],'LR',0);
    $pdf->Cell(40,5,$data['(SUM(nbractdec))'],'LR',0);
    
	
	if($pdf->GetStringWidth($data['FR']) > 65){
	$pdf->SetFont('Arial','',12);
	$pdf->Cell(25,5,$data['FR'],'LR',0);

	}else{
	$pdf->Cell(65,5,$data['FR'],'LR',0);
	}
	$pdf->Cell(80,5,$data['code_region'],'LR',1);
}














$pdf->Output();
?>